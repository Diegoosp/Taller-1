package test;

import modelo.Ventana;

/**
 *
 * @author bcast
 */
public class App {
    public static void main(String[] args) {
        Ventana v = new Ventana();
        v.setVisible(true);
    }
}
